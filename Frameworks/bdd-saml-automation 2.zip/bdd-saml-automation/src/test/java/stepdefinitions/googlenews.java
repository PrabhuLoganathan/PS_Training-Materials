package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class googlenews {







@Given("I want launch the browser with valid URL {string}")
public void i_want_launch_the_browser_with_valid_url(String string) {
   
}



@When("As user i want click on Google menu Icon")
public void as_user_i_want_click_on_google_menu_icon() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

;

@When("I select news app under the avilable Icon")
public void i_select_news_app_under_the_avilable_icon() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}


@Then("I need to verify the {string} text is present in the landing page")
public void i_need_to_verify_the_text_is_present_in_the_landing_page(String string) {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}



    
}
