package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Accounts {



@Given("my Current account has a balance of {double}")
public void my_current_account_has_a_balance_of(Double double1) {
    
}


@Given("my Savings account has a balance of {double}")
public void my_savings_account_has_a_balance_of(Double double1) {

}



@When("I transfer {double} from my Current account to my Savings account")
public void i_transfer_from_my_current_account_to_my_savings_account(Double double1) {

}



@Then("I should have {double} in my Current account")
public void i_should_have_in_my_current_account(Double double1) {
    
}



@Then("I should have {double} in my Savings account")
public void i_should_have_in_my_savings_account(Double double1) {

}




    
}
