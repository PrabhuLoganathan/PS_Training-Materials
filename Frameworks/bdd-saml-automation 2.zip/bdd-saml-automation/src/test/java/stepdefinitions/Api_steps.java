package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Api_steps {
	
	

@When("User sets Authoization to No  Auth.")
public void user_sets_authoization_to_no_auth() {

}


@Given("User creates GET Request for the LMS API endpoint")
public void user_creates_get_request_for_the_lms_api_endpoint() {

}


@When("User sends HTTPS Request")
public void user_sends_https_request() {

}



@Then("User receives {int} OK Status with response body.")
public void user_receives_ok_status_with_response_body(Integer int1) {

}




}
