package stepdefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import factory.DriverFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Google_steps {

	WebDriver driver;

	@Given("user launch the url {string}")
	public void user_launch_the_url(String url) {

		driver = DriverFactory.getDriver();

		driver.get(url);
	}

	@Then("user validate the title")
	public void user_validate_the_title() {

		driver.findElement(By.xpath("//*[@id='username']")).sendKeys("exampleteacher");
		driver.findElement(By.xpath("//*[@id='password']")).sendKeys("Test123#");
		driver.findElement(By.xpath("//*[@type='submit']")).click();

		List<WebElement> list1 = driver.findElements(
				By.xpath("//*[@class=' aalink stretched-link']//following-sibling::span[@class='instancename']"));

		for (WebElement company1 : list1) {
			String name = company1.getText();
			System.out.println(name);
		}

	}



	@Then("User verify that main header text {string} is displayed")
	public void user_verify_that_main_header_text_is_displayed(String MainText) {


		hightLightElement(driver.findElement(By.xpath("//*[@aria-label='" + MainText + "']//following::h3")));
	}

	@Then("User verify that sub-header text {string} is displayed")
	public void user_verify_that_sub_header_text_is_displayed(String subHeader) {

		hightLightElement(driver.findElement(By.xpath("(//*[@data-activityname='" + subHeader + "'])[1]")));
	}

	public WebElement hightLightElement(WebElement element) {
		if (DriverFactory.getDriver() instanceof JavascriptExecutor) {
			((JavascriptExecutor) DriverFactory.getDriver()).executeScript("arguments[0].style.border='3px solid red'",
					element);
		}
		return element;
	}

}
