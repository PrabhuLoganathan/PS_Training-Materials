package test;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import config.EnvironmentSetup;
import pgfactorymodelrepo.DeleteFormElmts;
import pgfactorymodelrepo.LoginPage;
import pgfactorymodelrepo.LogoutPage;
import utils.CustomScreenshot;

import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.AfterSuite;

public class DeleteForm extends EnvironmentSetup {
	public static WebDriver driver;

	@Test(priority = 0)
	public void openUrl() {
		driver.manage().window().maximize();
		driver.get("https://www.mycontactform.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(priority = 1, dependsOnMethods = { "openUrl" })
	@Parameters({ "username", "password" })
	public void validLogin(String username, String password) {
		// Page Factory Model
		LoginPage loginPage = new LoginPage(driver);
		// Login - test parameters with input from testng.xml at suite/test level
		WebElement userNameElmt = loginPage.login();
		userNameElmt.clear();
		userNameElmt.sendKeys(username);

		WebElement passwordElmt = loginPage.passwd();
		passwordElmt.clear();
		passwordElmt.sendKeys(password);

		WebElement submitBtn = loginPage.submit();
		submitBtn.click();
	}

	/** Hardcoded form name in DeleteFormElmts class*/
	//@Test(priority = 2)
	public void deleteFormByName() {
		// Page Factory Model
		DeleteFormElmts delForm = new DeleteFormElmts(driver);
		delForm.delForm().click();
		delForm.inputTxt().sendKeys("yes");
		delForm.delButton().click();
		WebElement success_msg = delForm.successMessage();
		System.out.println(success_msg.getText());
		AssertJUnit.assertEquals("SUCCESS", success_msg.getText());
	}

	@Test(priority = 2)
	public void deleteManyForms() {
		// Form names to delete
		String formCollections = "untitled - untitled - untitled - untitled - untitled";
		String[] formNames = formCollections.split("-");
		// Page Factory Model
		DeleteFormElmts delForm = new DeleteFormElmts(driver);
		List<WebElement> tableRows = delForm.getTableRows();
		int size = tableRows.size();
		for (String formName : formNames) {
			formName = formName.trim();
			for (int index = 0; index < size; index++) {
				System.out.println(formName);				
				String rowVal = tableRows.get(index).getText();
				//System.out.println(rowVal);
				if (rowVal.contains(formName)) {					
					tableRows.get(index).findElement(By.linkText("Delete")).click();
					delForm.inputTxt().sendKeys("yes");
					delForm.delButton().click();
					//break;
				}
			}
		}
	}

	//@AfterMethod
	public void afterMethod() {
		// CustomScreenshot.takeScreenshot(driver, "sc1");
	}

	@BeforeTest
	public void setupEnvironment() {
		EnvironmentSetup setup = new EnvironmentSetup();
		setup.setDriver(driver);
		driver = setup.getDriver();
	}

	@AfterTest
	public void afterTest() {
		LogoutPage logoutPg = new LogoutPage(driver);
		logoutPg.logout().click();
	}

	@AfterSuite
	public void afterSuite() {
		driver.close();
	}

}
