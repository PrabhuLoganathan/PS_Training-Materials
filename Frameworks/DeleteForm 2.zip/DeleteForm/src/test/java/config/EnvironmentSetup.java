package config;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class EnvironmentSetup {
	public WebDriver driver;

	public WebDriver getDriver() {
		return this.driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
		//System.setProperty("webdriver.chrome.driver", "C:\\Project Stuff\\chromedriver_win32\\chromedriver.exe");
		this.driver = new ChromeDriver();
	}
	
}
