package utils;

import java.io.File;
import java.io.IOException;


import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

public class CustomScreenshot {
	
	public static void takeScreenshot(WebDriver driver, String screenshotName) {
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileHandler.copy(source, new File("./src/test/java/screenshot/"+screenshotName+".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
