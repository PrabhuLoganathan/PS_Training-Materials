package pgfactorymodelrepo;



import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DeleteFormElmts {
	
	WebDriver driver;
	
	public DeleteFormElmts(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(className="highlight")
	List<WebElement> tableRows;
	
	@FindBy(xpath="//*[text()='MCf34']//following::a[text()='Delete'][1]")
	WebElement locateFormToDel;

	@FindBy(xpath="//input[@id='deleteauth']")
	WebElement inputText;
	
	//@FindBy(xpath="//input[contains(@value,'MCf34')]")
	@FindBy(name="submit")
	WebElement delBtn;
	
	@FindBy(xpath="//span[contains(text(),'SUCCESS')]")
	WebElement successMsg;
	
	public List<WebElement> getTableRows() {
		return tableRows;
	}
	
	public WebElement delForm() {
		return locateFormToDel;
	}
	
	public WebElement inputTxt() {
		return inputText;
	}
	
	public WebElement delButton() {
		return delBtn;
	}
	
	public WebElement successMessage() {
		return successMsg;
	}
}
