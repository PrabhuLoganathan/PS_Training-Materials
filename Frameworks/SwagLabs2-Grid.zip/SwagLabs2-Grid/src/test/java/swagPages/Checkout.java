package swagPages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Checkout {

	WebDriver driver;

	public Checkout(WebDriver driver) {
		this.driver = driver;

	}

	@FindBy(className = "checkout_button")
	WebElement checkoutButton;

	@FindBy(className = "form_input")
	List<WebElement> formElements;

	@FindBy(id = "continue")
	WebElement continueButton;

	@FindBy(id = "finish")
	WebElement finishButton;
	
	@FindBy(id = "back-to-products")
	WebElement backToHomeButton;

	public Checkout proceedToCheckout() {
		checkoutButton.click();
		HoldPage.hold();

		return PageFactory.initElements(driver, Checkout.class);
	}

	public Checkout enterInformation() {
		
		formElements.get(0).sendKeys("a");
		formElements.get(1).sendKeys("b");
		formElements.get(2).sendKeys("c");
		
		Wait<WebDriver> wait = new WebDriverWait(driver, Duration.ofSeconds(3));
		wait.until(d -> continueButton.isDisplayed());
		
		continueButton.click();
		HoldPage.hold();

		return PageFactory.initElements(driver, Checkout.class);
	}

	public Inventory finishCheckout() {
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		
		finishButton.click();
		backToHomeButton.click();
		
		HoldPage.hold();
		return PageFactory.initElements(driver, Inventory.class);

	}
}
