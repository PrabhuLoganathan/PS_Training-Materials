package swagPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginPage {

	WebDriver driver;

	public LoginPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	@FindBy(className = "login_logo")
	WebElement titleElement;

	@FindBy(id = "user-name")
	WebElement usernameElement;

	@FindBy(id = "password")
	WebElement passwordElement;

	@FindBy(id = "login-button")
	WebElement loginButtonElement;
	
	public void checkTitle() {
		Assert.assertEquals(titleElement.getText(), "Swag Labs");
	}

	public Inventory loginTest(String username, String password) {
			
		usernameElement.clear();
		usernameElement.sendKeys(username);
		passwordElement.clear();
		passwordElement.sendKeys(password);
		loginButtonElement.click();

		Inventory inventory = PageFactory.initElements(driver, Inventory.class);
		return inventory;
	}
}
