package swagPages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Inventory {
	
	WebDriver driver;
	
	@FindBy(xpath = "//*[@id=\"header_container\"]/div[2]/span")
	List<WebElement> titleElement;
	
	@FindBy(className = "btn_inventory")
	List<WebElement> addToCartButtons;
	
	@FindBy(className = "shopping_cart_link")
	WebElement cartIcon;
	
	public Inventory(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public boolean verifyLogin() {
		if(titleElement.size() > 0)
			return true;
	
		return false;	
	}
	
	public int addAllToCart() {
		for(WebElement button : addToCartButtons) {
			button.click();
		}
		return addToCartButtons.size();
	}
	
	public void viewCart() {
		cartIcon.click();
	}

	public WebDriver getDriver() {
		return driver;
	}

	public List<WebElement> getTitleElement() {
		return titleElement;
	}

	public List<WebElement> getAddToCartButtons() {
		return addToCartButtons;
	}
	
}
