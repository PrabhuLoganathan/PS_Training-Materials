package swagPages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Cart {
	
	WebDriver driver;
	
	public Cart(WebDriver driver) {
		this.driver = driver;
	}
	
	@FindBy(className = "inventory_item_name")
	List<WebElement> cartItems;
	
	public boolean validateItemCount() {
		Inventory inventory = PageFactory.initElements(driver, Inventory.class);
		
		return(cartItems.size() == inventory.getAddToCartButtons().size());
	}
	
	public void removeFromCart(String itemName) {
		String myXPath = "//button[@name = '" + itemName + "']";
		WebElement removeButton = driver.findElement(By.xpath(myXPath));
		
		HoldPage.hold();
		removeButton.click();
		HoldPage.hold();
		
	}
}
