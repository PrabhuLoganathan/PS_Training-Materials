package Base;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import configureProperties.ConfigureProperties;

public class TestBase {

	protected WebDriver driver;
	protected ConfigureProperties config;
	
	@BeforeClass
	public void setup() {
		
		config = new ConfigureProperties();
		
		String browser = config.getProperty("browser");
		
		String gridURL = "http://10.202.97.85:8000";

		switch (browser) {
		case "chrome":
			ChromeOptions chromeOptions = new ChromeOptions();
			
			try {
				//driver = new RemoteWebDriver(new URL(gridURL), chromeOptions);
				driver = new ChromeDriver();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "edge":
			EdgeOptions edgeOptions = new EdgeOptions();
			try {
				driver = new RemoteWebDriver(new URL(gridURL), edgeOptions);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		default:
			break;
		}
		
		driver.manage().window().maximize();
		driver.get(config.getProperty("URL"));
	}
	
	@AfterClass
	public void teardown() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.quit();
	}

}
