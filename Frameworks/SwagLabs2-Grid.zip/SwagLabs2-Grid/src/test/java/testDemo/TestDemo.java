package testDemo;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.TestBase;
import swagPages.Cart;
import swagPages.Checkout;
import swagPages.HoldPage;
import swagPages.Inventory;
import swagPages.LoginPage;

@Listeners(ngListener.NGListener.class)
public class TestDemo extends TestBase {
		
	@Test(priority = 1, description = "Checking the landing page.")
	public void checkLandingPage() {
		LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);
		
		loginPage.checkTitle();
			
	}

	@Test(priority = 3, description = "Testing valid login.", enabled = false)
	public Inventory checkValidLogin() {
		
		LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);
		
		System.out.println(loginPage.loginTest(config.getProperty("validUsername"), config.getProperty("validPassword")).verifyLogin() ? "Login is successful." : "Login is unsuccessful.");
		
		return PageFactory.initElements(driver, Inventory.class);
	}
	
	@Test(priority = 2, description = "Testing invalid login.")
	public void checkInvalidLogin() {
		
		LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);
		
		System.out.println(loginPage.loginTest(config.getProperty("invalidUsername"), config.getProperty("invalidPassword")).verifyLogin() ? "Login is successful." : "Login is unsuccessful.");
	}
	
	@Test(priority = 4, description = "Proceeding to inventory & adding all items to cart.")
	public void addToCart() {
		
		Inventory inventory = checkValidLogin();
					
		System.out.println(inventory.addAllToCart() + " Items added to cart.");
		HoldPage.hold();
		inventory.viewCart();
	}
	
	@Test(priority = 5, description = "Checking cart item count.")
	public void cart() {
		
		Cart cart = PageFactory.initElements(driver, Cart.class);
		
		if(cart.validateItemCount())
			System.out.println("Valid cart item count.");
		else
			System.out.println("Inavlid cart item count.");
		
		cart.removeFromCart("remove-sauce-labs-backpack");
	}
	
	@Test(priority = 6, description = "Proceeding to checkout.")
	public void checkOut() {
		Checkout checkout = PageFactory.initElements(driver, Checkout.class);
		
		checkout.proceedToCheckout().enterInformation().finishCheckout();
	}

}
