package reportNGTest;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Demo {
	
	@Test
	public void demoTest() {
		
		//WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		driver.get("http://tutorialsninja.com/demo/index.php?route=account/login");
		driver.findElement(By.id("input-email")).sendKeys("arun.selenium@gmail.com");
		driver.findElement(By.id("input-password")).sendKeys("Second@123");
		driver.findElement(By.xpath("//input[@value='Login']")).click();
		
		AssertJUnit.assertTrue(driver.findElement(By.xpath("//a[.='Edit your account information']")).isDisplayed());
		
		driver.close();
		
	}

}