package ActionClassDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Action1 {

	public void main(String[] args) {
		// specify the driver location
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		WebElement element = driver.findElement(By.xpath("//input[@title=’Search’]"));
		Actions action = new Actions(driver);
		action.sendKeys(element, "Iphone").build().perform();
		// Close the browser driver.quit(); } }
	}
}