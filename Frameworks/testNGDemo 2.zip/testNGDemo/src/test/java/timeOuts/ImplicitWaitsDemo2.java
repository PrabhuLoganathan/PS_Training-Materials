package timeOuts;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base.BasaClass;

public class ImplicitWaitsDemo2  extends BasaClass{

	



	@Test(priority = 2,description = "We are doing valid login")
	public void testCase() {

		
		driver.get("https://www.mycontactform.com");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		
		wait.until(ExpectedConditions.titleIs("Free Contact and Email Forms - myContactForm.com"));
		
		
		wait.until(ExpectedConditions.urlToBe("Free Contact and Email Forms - myContactForm.com"));
		
		System.out.println(driver.getTitle());
	
		Assert.assertEquals(driver.getTitle(), "Free Contact and Email Forms - myContactForm.com");

	WebElement loginElements = driver.findElement(By.tagName("inut"));

		loginElements.sendKeys("Prabhu123");

//		loginElements.get(1).sendKeys("12345");
//
//		loginElements.get(2).click();

		System.out.println(driver.getTitle());
		
		Assert.assertEquals(driver.getTitle(),"Form Magement - myContactForm.com" );

	}



}
