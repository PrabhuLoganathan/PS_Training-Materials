package test;

import org.testng.annotations.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import base.BasaClass;
import pageObjects.LoginPage;

public class TestPO2  extends BasaClass {
	
	
	@Test
	public void  test_e2e() {
		
		
		driver.get("https://www.mycontactform.com/");
		
		LoginPage logingPageObject = PageFactory.initElements(driver,LoginPage.class);
		
		
		//logingPageObject.getUsernameElement().sendKeys("");
//		
		//logingPageObject.doInValidLogin();
		
		logingPageObject.doValidLogin();
		
		
	}

}
