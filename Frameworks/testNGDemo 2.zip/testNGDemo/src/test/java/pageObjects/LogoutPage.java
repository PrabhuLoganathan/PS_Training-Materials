package pageObjects;

public class LogoutPage {

}
