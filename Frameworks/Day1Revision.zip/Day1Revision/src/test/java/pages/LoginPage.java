package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {

	@FindBy(id = "user")
	WebElement username;
	
	
	@FindBy(xpath = "//*[@id='pass']")
	WebElement password;
	
	
	@FindBy(css = "input.btn_log")
	WebElement loginButton;
	
	
	
	public void login(String user, String pass) {
		username.sendKeys(user);
		password.sendKeys(pass);
		loginButton.click();
	}
	
	

}
