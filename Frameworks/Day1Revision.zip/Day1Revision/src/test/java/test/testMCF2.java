package test;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestListener;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.BaseClass;
import pages.LoginPage;

@Listeners(listeners.NGListener.class)

public class testMCF2  extends BaseClass{
	
	
	@Test
	public void test() {
		
	 LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);
	 
	 loginPage.login("Prabhu123", "12345");
		
	}
	

}
